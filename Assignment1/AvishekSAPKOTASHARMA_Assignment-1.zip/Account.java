/* 
* Author: Avishek Sapkota Sharma
* Student No: 3393440
* Date: 08-04-2022
*/

public class Account{
    double rate;
    int numberOfWeeks;
    double amount;
    double totalAmount;
 
    public Account(){
    
    }
     
    public void setData(double investmentAmount, double interestRate, int investmentLength){
        rate = interestRate;
        numberOfWeeks = investmentLength;
        amount = investmentAmount;
        //assigning values to the null variables
    }
    
    public double getInterestAmountForWeek(int weekNumber){
        totalAmount += amount*4;
        totalAmount *=  1+((rate/100)/13);
        return (totalAmount);
        //calculating the interest amount for specific week and returning the double value to the method that called it
    }
}
