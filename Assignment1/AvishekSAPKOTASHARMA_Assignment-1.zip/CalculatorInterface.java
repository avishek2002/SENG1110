/* 
* Author: Avishek Sapkota Sharma
* Student No: 3393440
* Date: 08-04-2022
*/

import java.util.*;

public class CalculatorInterface{
    
    public void run(Scanner console){
        Client client = new Client();
        String inputName;
        double annualIncome;
        boolean residencyStatus;
        String auxResidencyStatus;
        double expenditure;
        double investmentValue;
        double interestRate;
        int investmentLength;
        
        do{
            System.out.print("Name : ");
            inputName = console.nextLine();
        }
        while(inputName==null);
        //runs the do..while loop until inputName is not null
        do{
            System.out.print("Annual income : ");
            annualIncome = console.nextDouble();
        }
        while(annualIncome<=0);
        //runs the do..while loop until annualIncome is greater than 0
        do{
            System.out.print("Residency(true/false) : ");
            auxResidencyStatus = console.next();
            auxResidencyStatus = auxResidencyStatus.toLowerCase();
            System.out.println(auxResidencyStatus);
            System.out.println(!(auxResidencyStatus.equals("true")) && !(auxResidencyStatus.equals("false")));
        }
        while(!(auxResidencyStatus.equals("true")) && !(auxResidencyStatus.equals("false")));
        //runs the do..while loop until auxResidencyStatus is not equal to "true" or "false"
        //auxResidencyStatus is used so that the user input can be checked and looped if it is not boolean
        residencyStatus = Boolean.parseBoolean(auxResidencyStatus);
        //Boolean.parseBoolean(str) is used to change the type of str to boolean
        
        client.setData(inputName,annualIncome,residencyStatus);
        System.out.println("\nName: " + client.getName());
        //calling the method getName() from Client class
        System.out.println("\nNet Salary\n" + "Per Week: $" + Math.round((client.netSalary/52)*100.0)/100.0);
        //rounding up the net salary, public variable netSalary(in Client class), to the second decimal place
        System.out.println("Per Year: $" + Math.round(client.netSalary*100.0)/100.0);
        //rounding up the net salary, public variable netSalary(in Client class), to the second decimal place
        System.out.println("\nTax Paid\n" + "Per Week: $" + Math.round((client.tax/52)*100.0)/100.0);
        //rounding up the tax, public variable tax(in Client class), to the second decimal point
        System.out.println("Per Year: $" + Math.round(client.tax*100.0)/100.0);
        //rounding up the tax, public variable tax(in Client class), to the second decimal point
        System.out.println("\nMedicare Levy Per Year: $" + client.medicare);
        //calling the public variable medicare from Client class
        
        System.out.print("\nWeekly expenditure : ");
        expenditure = console.nextDouble();
        while (expenditure<1 || expenditure>(client.netSalary/52)){
            //runs the while loop until the expenditure is a positive integer less than weekly salary
            System.out.println("Your expenditure cannot be negative, equal to zero or less than your weekly net salary!");
            System.out.print("Do you want to re-enter your expenditure(1) or your annual income(2) or exit(3) : ");
            int option = console.nextInt();
            if (option==1){
                System.out.print("Re-enter your expenditure : ");
                expenditure = console.nextDouble();
            }
            else if (option==2){
                System.out.print("Re-enter your annual income : ");
                annualIncome = console.nextDouble();
                client.changeAnnualIncome(annualIncome);
                //changes the annual income in the Client class
            }
            else if (option==3){
                System.exit(0);
                //terminates the program
            }
            else {
                System.out.println("Option " + option + " is invalid!");
            }
        }
        
        if ((client.netSalary/52)-expenditure>0){
            System.out.print("\nWould you like to invest some money(y/n)? : ");
            char option = console.next().charAt(0);
            //assigns the variable with charater at 0th index
            option = Character.toLowerCase(option);
            //changing option to lowercase alphabets
            if (option=='y'){
                //enters the if loop if option is equal to 'y'
                System.out.print("Investment amount : ");
                investmentValue = console.nextDouble();
                while (investmentValue<0 || (client.netSalary/52)-expenditure-investmentValue<0){
                    //runs the while loop until the input is a positive integer less/equal to weekly salary minus expenditure
                    System.out.println("Investment amount not feasible!");
                    System.out.print("Re-enter investment amount : ");
                    investmentValue = console.nextDouble();
                }
                System.out.print("Interest rate : ");
                interestRate = console.nextDouble();
                while (interestRate>20 || interestRate<1){
                    //runs the while loop until the rate is within range 1 and 20
                    System.out.println("Interest rate must be within range 1% and 20%!");
                    System.out.print("Re-enter interest rate : ");
                    interestRate = console.nextDouble();
                }
                System.out.print("Investment length(# of weeks) : ");
                investmentLength = console.nextInt();
                while (investmentLength<=0){
                    //runs the loop while time period is less/equal to 0
                    System.out.println("Investment length cannot be less than or equal to zero!");
                    System.out.print("Re-enter investment length(weeks) : ");
                    investmentLength = console.nextInt();
                }
                
                client.setDataToAccount(investmentValue, interestRate, investmentLength);
                //sends the arguements to the method in Client class, which further sends them to Account class
                
                System.out.println("Weeks\tBalance");
                System.out.println("-".repeat(15));
                //repeating string 25 times
                int weekNumber;
                double weekAmount = 0;
                for (weekNumber = 4; weekNumber<=investmentLength; weekNumber+=4){
                    //continues the loop, incrementiing the value of weekNumber by 4, whiel it is less/equal to time period
                    System.out.print(weekNumber + "\t");
                    weekAmount = client.getMonthlyAmount(weekNumber);
                    //retrieving weekly amount from another class
                    System.out.print("$" + Math.round(weekAmount*100.0)/100.0 + "\n");
                    //rounds up the weekAmount to second decimal
                }
                weekNumber -= 4; 
                //for the last iteration, weekNumber increases by 4 and weekNumber>investment, won't execute
                if (weekNumber<investmentLength){
                    //amount for last week if number of weeks is not divisible by 4
                    //interest is not applied for these weeks
                    System.out.print(investmentLength + "\t");
                    weekAmount += investmentValue*(investmentLength-weekNumber);
                    System.out.print("$" + Math.round(weekAmount*100.0)/100.0 + "\n");
                }
            }
        }
    }
    
    public static void main(String[] args){
        Scanner console = new Scanner (System.in);

        CalculatorInterface calc = new CalculatorInterface();
        char option = 'y';
        do{
            calc.run(console);
            System.out.println("*".repeat(50));
            System.out.print("Would you like to continue(y/n)? ");
            option = console.next().charAt(0);
            //assigns value at 0th index to option
            option = Character.toLowerCase(option);
            //changes option to lowercase, if it was uppercase
            console.nextLine();
            System.out.println("*".repeat(50));
        }
        while(option=='y');
        //loops through method run() while option is equal to 'y'
    }
    
}
        
    

    
    
    
    
    
    
    


        

    