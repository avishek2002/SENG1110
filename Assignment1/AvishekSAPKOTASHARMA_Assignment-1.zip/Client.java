/* 
* Author: Avishek Sapkota Sharma
* Student No: 3393440
* Date: 08-04-2022
*/

public class Client{
    private String name;                     
    private Account savingAccount = new Account();
    double grossSalary;
    double netSalary;
    boolean resident;
    double tax;
    double medicare;
    double weeklyExpenses;

    public Client(){

    }

    public String getName(){
        return (name);
        //returns the name of the client to the method in CalculatorInterface that called it
    }
    public double getMonthlyAmount(int weekNumber){
         return (savingAccount.getInterestAmountForWeek(weekNumber));
         //returns the interest amount for week to the method in CalculatorInterface, after retrieving it from Account class
    }
    
    public void setData(String inputName, double annualSalary, boolean residencyStatus){
        name = inputName;
        grossSalary = annualSalary;
        resident = residencyStatus;
        
        calcTax();
        //calling calcTax method
        calcMedicare();
        //calling calcMedicare method
        netSalary = grossSalary - tax - medicare;
        //calculating netSalary, after tax and medicare
        //tax and medicare have been assigned a value from the two methods we called earlier
    }
    public void changeAnnualIncome(double annualSalary){
        grossSalary = annualSalary;
        //changing the value of grossSalary
        calcTax();
        calcMedicare();
        netSalary = grossSalary - tax - medicare;
        //calculating netSalary after grossSalary was changed
    }
    public void setDataToAccount(double investmentValue, double interestRate, int investmentLength){
        savingAccount.setData(investmentValue, interestRate, investmentLength);
        //pushing the data to the method in Account class
    }
    
    private void calcTax(){
        if (resident==true){
            //performs the following operations if the client is a resident
            if (grossSalary>0 && grossSalary<=18200){
                tax = 0;
            }
            else if (grossSalary>18200 && grossSalary<=45000){
                tax = (grossSalary-18200)*0.19;
            }
            else if (grossSalary>45000 && grossSalary<=120000){
                tax = 5092 + (grossSalary-45000)*0.325;
            }
            else if (grossSalary>120000 && grossSalary<=180000){
                tax = 29467 + (grossSalary-120000)*0.37;
            }
            else if (grossSalary>180000){
                tax = 52667 + (grossSalary-180000)*0.45;
            }
        }
        else if (resident==false){
            //performs the following operations if the client is not a resident
            if (grossSalary>0 && grossSalary<=120000){
                tax = grossSalary*0.325;
            }
            else if (grossSalary>120000 && grossSalary<=180000){
                tax = 39000 + (grossSalary-120000)*0.37;
            }
            else if (grossSalary>180000){
                tax = 61200 + (grossSalary-180000)*0.45;
            }
        }
    }
    private void calcMedicare(){
        if (resident==true && grossSalary>29032){
            medicare = grossSalary*0.02;
            //calculating medicare for residents
        }
        else {
            //medicare is not applicable to non-residents
            medicare = 0;
        }
    }
    
}
